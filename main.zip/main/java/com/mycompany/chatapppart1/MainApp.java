/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

/**
 *
 * @author Student
 */
import java.util.Scanner;


public class MainApp { 
    public static void main(String[]args){
        
        Scanner input = new Scanner(System.in);
        
        Login login = new Login();
      
        System.out.println("=== USER REGISTRATION===");
        
        System.out.println("Enter a username: ");
        String username = input.nextLine();
        
        System.out.println("Enter a password: ");
        String password = input.nextLine();
        
        System.out.println("Enter your South Africa phone number(+27...): ");
        String phoneNumber = input.nextLine();
        
        String response = login.registerUser(username, password, phoneNumber);
        
        System.out.println(response);
        
        System.out.println("\n=== USER LOGIN ===");
      
        System.out.println("Enter your username ");
        String loginUsername = input.nextLine();
        
        System.out.println("Enter your password ");
        String loginPassword = input.nextLine();
        
         boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        
         String loginMessage = login.returnLoginStatus(loggedIn );
        System.out.println(loginMessage);
        
        }
     
    }

